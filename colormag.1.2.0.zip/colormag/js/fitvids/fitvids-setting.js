/*
 * FitVids Setting
 */
jQuery(document).ready(function () {
   jQuery('.fitvids-video').fitVids();
});
