wow = new WOW({ offset: 140 });
wow.init();