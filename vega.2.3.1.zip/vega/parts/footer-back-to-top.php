<?php
/**
 * The template part for displaying the 'back to top' link/button
 *
 * @package vega
 */
?>
<!-- Back to Top -->
<div id="back_to_top">
    <div class="container">
        <a href="#"><i class="fa fa-chevron-up"></i></a>
    </div>
</div>
<!-- /Back to Top -->