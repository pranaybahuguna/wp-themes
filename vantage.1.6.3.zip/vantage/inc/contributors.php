<?php
return json_decode( '{
	"85ce7a450a7ee4895f3bd823505e2e12": {
		"name": "adiraomj",
		"email": "85ce7a450a7ee4895f3bd823505e2e12",
		"loc": 1760,
		"score": 99.629307292943,
		"percent": 54.457737780032744
	},
	"36639e6e074b731b093bde5a77305179": {
		"name": "Braam Genis",
		"email": "36639e6e074b731b093bde5a77305179",
		"loc": 2366,
		"score": 50.52645327564673,
		"percent": 27.617941128003267
	},
	"b7122312e4008f8f2c76911080bca01a": {
		"name": "Andrew Misplon",
		"email": "b7122312e4008f8f2c76911080bca01a",
		"loc": 522,
		"score": 30.91212664821442,
		"percent": 16.896679631444787
	},
	"a885c7bd5442dd2acd8c3e42001332c6": {
		"name": "Alex S",
		"email": "a885c7bd5442dd2acd8c3e42001332c6",
		"loc": 26,
		"score": 1.5356932434818544,
		"percent": 0.8394154515016542
	},
	"07294cc1dd7658895e44c559dfffd76f": {
		"name": "gpriday",
		"email": "07294cc1dd7658895e44c559dfffd76f",
		"loc": 23,
		"score": 0.34435559862368303,
		"percent": 0.1882260090175599
	}
}', true );