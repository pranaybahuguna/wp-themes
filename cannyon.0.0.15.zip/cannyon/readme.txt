
    Cannyon


    Thank you for choosing myThem.es and use one of our WordPress Themes
    your choice is greatly appreciated!


    myThem.es Marketplace provides WordPress themes with
    the best quality and the smallest prices.
    

    Cannyon, Copyright 2015 myThem.es

    Cannyon is distributed under the terms of the
    GNU GENERAL PUBLIC LICENSE


   *****************************************************************************


                     ________________
                    |_____    _______|
     ___ ___ ___   __ __  |  |  __       ____   ___ ___ ___       ____   ____ 
    |   |   |   | |_ |  | |  | |  |___  |  __| |   |   |   |     |  __| |  __|
    |   |   |   |  | |  | |  | |  __  | |  __| |   |   |   |  _  |  __| |__  |
    |___|___|___|   |  |  |__| |_ ||_ | |____| |___|___|___| |_| |____| |____|   
                    |_|



   *****************************************************************************



    - Theme URI         : http://mythem.es/item/cannyon-free-wordpress-theme/
    - Support URI       : http://mythem.es/forums/forum/themes/cannyon/cannyon-free/

    - Author            : myThem.es
    - Author URI        : http://mythem.es

    - Demo URI          : http://test.mythem.es/cannyon-wordpress/


    
   *****************************************************************************



    - More about            : http://www.google.com/fonts#AboutPlace:about
    - Used Fonts            : Oleo Script Swash Caps, Montserrat, Open+Sans, Lato

    - Used Icons Fonts	    : Fontello
    - Fontello URI 	        : http://fontello.com/



   *****************************************************************************



    Header image licensed under Creative Commons Zero
    https://unsplash.com/apu889
	
    Bootstrap 3.3.1, Copyright (c) 2010-14, Twitter, Inc.
    Bootstrap is under the terms of MIT License.
    http://getbootstrap.com


    HTML5 Shiv v3.7.0, Copyright (c) @afarkas @jdalton @jon_neal @rem
    HTML5 Shiv v3.7.0 is under the terms of MIT License.

    jScrollPane - v2.0.20 - 2014-10-23 is dual licensed under the MIT or GPL licenses.
    http://jscrollpane.kelvinluck.com/

    Mousewheel 3.1.9, Copyright (c) 2013 Brandon Aaron
    Mousewheel 3.1.9 is under the terms of MIT License.
    http://brandon.aaron.sh

    prettyPhoto v3.1.5, Copyright (c) Stephane Caron
    prettyPhoto is under the terms of GPLV2 License.
    You are free to use prettyPhoto in commercial projects as long as the
    copyright header is left intact.

    http://www.no-margin-for-errors.com

    Respond.js v1.4.2, Copyright (c) 2013 Scott Jehl
    Respond.js v1.4.2 is under the terms of MIT License.
    http://scottjehl.com

    

   *****************************************************************************



    HOW TO USE


    1. WELCOME MESSAGE

    Thank you for choosing myThem.es and use one of our WordPress Themes your
    choice is greatly appreciated!

    If you have any questions ask!

    Before ask, please read all topics from our forums, marked as AUTHOR SUGGEST:
    http://mythem.es/forums/forum/themes/cannyon/cannyon-free/

    And please help us to increase the theme quality ( report bugs ).

    Also please help us to increase the theme rank!


    2. CUSTOMIZE YOUR THEME

    This theme comes with a set of options what allow you to customize content,
    header, layouts, social items and others.

    You can see theme options if you go to Admin Dashboard
    Appearance > Customize