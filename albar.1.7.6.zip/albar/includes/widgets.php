<?php
include get_template_directory().'/includes/widgets/alba-carousel.php';
include get_template_directory().'/includes/widgets/alba-heading.php';
include get_template_directory().'/includes/widgets/alba-icon.php';
?>