<?php get_template_part('templates/head'); ?>
	<body <?php body_class(); ?> >
		<?php do_action('pinnacle_after_body_open'); ?>
		<div id="wrapper" class="container">
		  	<?php get_template_part('templates/header'); ?>
			<div class="wrap contentclass" role="document">