<?php 
global $virtue; 

?>
<div class="sliderclass kad-mobile-slider">
	<div id="imageslider" class="container">
		<div class="videofit">
                <?php echo do_shortcode($virtue['mobile_video_embed']);?>
        </div>
    </div><!--Container-->
</div><!--feat-->