<?php
/*

- Force plugins to stop stating incorrect errors -
<?php wp_footer(); ?>

*/	

      get_template_part('templates/footer'); ?>
  </body>
</html>