panels-lite
===========

A placeholder version of SiteOrigin Page Builder that can render content and encourage your users to install the full Page Builder plugin.
